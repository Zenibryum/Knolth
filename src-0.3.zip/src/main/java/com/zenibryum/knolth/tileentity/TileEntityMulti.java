package com.zenibryum.knolth.tileentity;

import net.minecraft.tileentity.TileEntity;

public class TileEntityMulti extends TileEntity {

}
