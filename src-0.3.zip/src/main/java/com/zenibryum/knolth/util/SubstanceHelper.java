package com.zenibryum.knolth.util;

public class SubstanceHelper
{
	public static SubstanceHelper substanceBase = new SubstanceHelper();
	
	public static int UranylNitrate = 4706631;//#47D147;
	public static int NitricAcid = 16763219;//#FFC953
	
	private SubstanceHelper()
	{
	}
}